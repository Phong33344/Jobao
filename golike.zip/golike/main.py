"""
main.py - Entry point tương tác.

Mỗi lần chạy BẮT BUỘC hỏi user 5 trường GolikeAuth:
    GolikeAuth(
        token="eyJ...",               # JWT Bearer
        signing_key="...",            # browser: store.state.signing_key
        user_id=123456,
        username="your_username",
        device_id="32484704-...",     # UUID v4, nên giữ cố định
    )

Nếu config.json đã có đủ 5 trường → dùng làm default (Enter = giữ).
Sau khi nhập, lưu vào config.json để lần sau không phải nhập lại.

Chạy:
    python main.py
"""
import os
import sys

from app.ui import Colors, safe_print, show_banner, ask, ask_choice, mask
from app.utils.config import (
    CONFIG,
    save_config,
    set_field,
    has_auth,
    get_webhook,
    init_config_if_missing,
)
from app.auth import GolikeAuth
from app.providers import ALL_PROVIDERS
from app.single import SingleAccountRunner
from app.controllers import JobaoController


FILE_AUTH = 'au.txt'


# ===========================================================================
# GolikeAuth prompt
# ===========================================================================
def _print_auth_summary(auth: GolikeAuth) -> None:
    """In tóm tắt 5 trường GolikeAuth (che giấu token)."""
    safe_print(f"\n{Colors.BOLD_CYAN}── GolikeAuth trong config.json ──{Colors.RESET}")
    safe_print(f"  {Colors.CYAN}token      {Colors.WHITE}= {mask(auth.token)}")
    safe_print(f"  {Colors.CYAN}signing_key{Colors.WHITE}= {mask(auth.signing_key, 6)}")
    safe_print(f"  {Colors.CYAN}user_id    {Colors.WHITE}= {Colors.YELLOW}{auth.user_id}{Colors.RESET}")
    safe_print(f"  {Colors.CYAN}username   {Colors.WHITE}= {Colors.YELLOW}{auth.username}{Colors.RESET}")
    safe_print(f"  {Colors.CYAN}device_id  {Colors.WHITE}= {Colors.YELLOW}{auth.device_id}{Colors.RESET}")


def prompt_golike_auth(force_all: bool = False) -> GolikeAuth:
    """
    Hỏi 5 trường GolikeAuth.

    Flow:
        1. Nếu config đã có GolikeAuth HỢP LỆ → in summary, hỏi "dùng luôn (Y) / đổi (n)"
        2. Nếu config không có / không hợp lệ → gọi prompt() luôn
        3. Trong prompt(): Enter = giữ default (existing)

    Args:
        force_all: True = hỏi lại TẤT CẢ fields kể cả khi đã có.
    """
    existing = GolikeAuth.from_config()

    if existing is not None and not force_all:
        # Đã có auth hợp lệ → hỏi dùng luôn hay đổi
        _print_auth_summary(existing)
        ans = ask(
            f"\n{Colors.BOLD_WHITE}Đã có GolikeAuth trong config. Dùng luôn? (Y/n){Colors.RESET}",
            "y",
        ).lower()
        if ans in ("", "y", "yes"):
            safe_print(f"{Colors.GREEN}✓ Dùng GolikeAuth từ config{Colors.RESET}")
            return existing
        # User muốn đổi
        safe_print(f"{Colors.YELLOW}→ Sẽ hỏi lại các trường (Enter = giữ nguyên){Colors.RESET}")
        return GolikeAuth.prompt(existing=existing, force_all=False)

    # Chưa có auth / không hợp lệ / force_all
    if force_all:
        safe_print(f"{Colors.BOLD_YELLOW}Buộc nhập lại toàn bộ 5 trường GolikeAuth:{Colors.RESET}")
    else:
        safe_print(f"{Colors.BOLD_YELLOW}Chưa có GolikeAuth hợp lệ trong config.json.{Colors.RESET}")
    return GolikeAuth.prompt(existing=existing, force_all=force_all)


# ===========================================================================
# Webhook setup
# ===========================================================================
def ensure_webhook(ask_anyway: bool = False):
    if ask_anyway or not get_webhook():
        if ask_anyway:
            safe_print(f"\n{Colors.BOLD_WHITE}── Discord Webhook ──{Colors.RESET}")
        url = ask(
            "Discord Webhook URL (Enter = bỏ qua / tắt)",
            CONFIG.get('webhook_url', ''),
        )
        set_field('webhook_url', url.strip())
        if url.strip():
            safe_print(f"{Colors.GREEN}✓ Đã lưu webhook vào config.json{Colors.RESET}")
        else:
            safe_print(f"{Colors.YELLOW}Webhook tắt — multi mode sẽ không gửi report.{Colors.RESET}")
    return CONFIG['webhook_url']


def setup_on_first_run() -> GolikeAuth:
    """
    Khởi động: auto-create config, hỏi BẮT BUỘC GolikeAuth (5 trường).

    Nếu config đã có GolikeAuth hợp lệ:
        - In summary 5 trường
        - Hỏi "dùng luôn? (Y/n)" → Enter = dùng luôn
        - Nếu "n" → hỏi lại từng field (Enter = giữ nguyên)

    Nếu config rỗng / không hợp lệ:
        - Prompt đầy đủ 5 trường
    """
    init_config_if_missing()
    safe_print(f"{Colors.GREEN}✓ config.json đã sẵn sàng{Colors.RESET}")

    # Xác định xem có cần save lại config không
    existing_before = GolikeAuth.from_config()
    auth = prompt_golike_auth()

    # Chỉ save khi auth mới khác auth cũ (tránh ghi file thừa)
    if existing_before is None or auth.to_dict() != existing_before.to_dict():
        auth.save_to_config()
        safe_print(f"{Colors.GREEN}✓ Đã lưu GolikeAuth vào config.json{Colors.RESET}\n")
    else:
        safe_print(f"{Colors.CYAN}  (dùng lại từ config, không ghi đè){Colors.RESET}\n")

    # Webhook: hỏi 1 lần nếu rỗng (không bắt buộc)
    if not get_webhook():
        if ask("Bạn có muốn cấu hình Discord Webhook cho multi mode? (y/N)", "n").lower() == "y":
            ensure_webhook()
        else:
            safe_print(f"{Colors.YELLOW}  (Bỏ qua — có thể cấu hình sau trong menu){Colors.RESET}")

    return auth


# ===========================================================================
# Cấu hình menu
# ===========================================================================
def configure_jobs():
    while True:
        safe_print(f"\n{Colors.BOLD_WHITE}── Job settings ──{Colors.RESET}")
        safe_print(f"  {Colors.CYAN}so_luong_job {Colors.WHITE}= {Colors.YELLOW}{CONFIG['so_luong_job']}{Colors.RESET}  (số job / platform / vòng)")
        safe_print(f"  {Colors.CYAN}delay_giay   {Colors.WHITE}= {Colors.YELLOW}{CONFIG['delay_giay']}{Colors.RESET}   (giây giữa 2 job)")
        safe_print(f"  {Colors.CYAN}dung_sau_loi {Colors.WHITE}= {Colors.YELLOW}{CONFIG['dung_sau_loi']}{Colors.RESET}   (lỗi liên tiếp thì dừng)")

        idx = ask_choice(
            "Chỉnh cấu hình job:",
            [
                f"Số job / platform  (hiện: {CONFIG['so_luong_job']})",
                f"Delay giây         (hiện: {CONFIG['delay_giay']})",
                f"Dừng sau N lỗi    (hiện: {CONFIG['dung_sau_loi']})",
                "Quay lại",
            ],
        )
        if idx in (-1, 3):
            return
        if idx == 0:
            v = ask("Số job / platform", str(CONFIG['so_luong_job']))
            try:
                set_field('so_luong_job', max(1, int(v)))
            except ValueError:
                safe_print(f"{Colors.RED}Không hợp lệ, giữ nguyên.{Colors.RESET}")
        elif idx == 1:
            v = ask("Delay (giây)", str(CONFIG['delay_giay']))
            try:
                set_field('delay_giay', max(0, int(v)))
            except ValueError:
                safe_print(f"{Colors.RED}Không hợp lệ, giữ nguyên.{Colors.RESET}")
        elif idx == 2:
            v = ask("Dừng sau N lỗi", str(CONFIG['dung_sau_loi']))
            try:
                set_field('dung_sau_loi', max(1, int(v)))
            except ValueError:
                safe_print(f"{Colors.RED}Không hợp lệ, giữ nguyên.{Colors.RESET}")


def configure_auth():
    """Đổi 5 trường GolikeAuth."""
    safe_print(f"\n{Colors.BOLD_WHITE}── GolikeAuth hiện tại ──{Colors.RESET}")
    safe_print(f"  {Colors.CYAN}token       {Colors.WHITE}= {mask(CONFIG.get('token', ''))}")
    safe_print(f"  {Colors.CYAN}signing_key {Colors.WHITE}= {mask(CONFIG.get('signing_key', ''), 6)}")
    safe_print(f"  {Colors.CYAN}user_id     {Colors.WHITE}= {Colors.YELLOW}{CONFIG.get('user_id', 0)}")
    safe_print(f"  {Colors.CYAN}username    {Colors.WHITE}= {Colors.YELLOW}{CONFIG.get('username', '')}")
    safe_print(f"  {Colors.CYAN}device_id   {Colors.WHITE}= {Colors.YELLOW}{CONFIG.get('device_id', '')}")

    idx = ask_choice(
        "Chỉnh GolikeAuth:",
        [
            "Đổi tất cả 5 trường (prompt lại)",
            "Đổi riêng từng trường",
            "Xoá GolikeAuth (sẽ hỏi lại lúc khởi động)",
            "Quay lại",
        ],
    )
    if idx in (-1, 3):
        return
    if idx == 0:
        auth = prompt_golike_auth(force_all=True)
        auth.save_to_config()
        safe_print(f"{Colors.GREEN}✓ Đã cập nhật GolikeAuth{Colors.RESET}")
    elif idx == 1:
        configure_auth_individual()
    elif idx == 2:
        for k in ('token', 'signing_key', 'user_id', 'username', 'device_id'):
            set_field(k, "" if k != 'user_id' else 0)
        safe_print(f"{Colors.YELLOW}Đã xoá GolikeAuth khỏi config.{Colors.RESET}")


def configure_auth_individual():
    """Đổi từng field riêng lẻ."""
    safe_print(f"\n{Colors.BOLD_WHITE}── Chỉnh từng field ──{Colors.RESET}")
    idx = ask_choice(
        "Chọn field:",
        [
            "token (JWT Bearer)",
            "signing_key (32B Base64)",
            "user_id (số)",
            "username",
            "device_id (UUID)",
            "Quay lại",
        ],
    )
    if idx in (-1, 5):
        return
    if idx == 0:
        v = ask("token mới", "")
        if v:
            set_field('token', v)
            safe_print(f"{Colors.GREEN}✓ Đã cập nhật token{Colors.RESET}")
    elif idx == 1:
        v = ask("signing_key mới", "")
        if v:
            set_field('signing_key', v)
            safe_print(f"{Colors.GREEN}✓ Đã cập nhật signing_key{Colors.RESET}")
    elif idx == 2:
        v = ask("user_id mới", str(CONFIG.get('user_id', 0)))
        try:
            set_field('user_id', int(v))
            safe_print(f"{Colors.GREEN}✓ Đã cập nhật user_id{Colors.RESET}")
        except ValueError:
            safe_print(f"{Colors.RED}Không hợp lệ.{Colors.RESET}")
    elif idx == 3:
        v = ask("username mới", CONFIG.get('username', ''))
        if v:
            set_field('username', v)
            safe_print(f"{Colors.GREEN}✓ Đã cập nhật username{Colors.RESET}")
    elif idx == 4:
        v = ask("device_id mới", CONFIG.get('device_id', ''))
        if v:
            set_field('device_id', v)
            safe_print(f"{Colors.GREEN}✓ Đã cập nhật device_id{Colors.RESET}")


def configure_webhook():
    current = CONFIG.get('webhook_url', '')
    safe_print(f"\n{Colors.BOLD_WHITE}── Discord Webhook ──{Colors.RESET}")
    safe_print(f"  Hiện tại: {Colors.CYAN}{mask(current, keep=16)}{Colors.RESET}")

    idx = ask_choice(
        "Chỉnh Webhook:",
        [
            "Đổi / đặt webhook URL",
            "Tắt webhook (set rỗng)",
            "Test gửi 1 message",
            "Quay lại",
        ],
    )
    if idx in (-1, 3):
        return
    if idx == 0:
        url = ask("Webhook URL mới", current)
        set_field('webhook_url', url.strip())
        safe_print(f"{Colors.GREEN}✓ Đã lưu webhook{Colors.RESET}" if url.strip()
                   else f"{Colors.YELLOW}Webhook đã tắt.{Colors.RESET}")
    elif idx == 1:
        set_field('webhook_url', '')
        safe_print(f"{Colors.YELLOW}Đã tắt webhook.{Colors.RESET}")
    elif idx == 2:
        url = current.strip()
        if not url:
            safe_print(f"{Colors.RED}Webhook rỗng — đặt URL trước đã.{Colors.RESET}")
            return
        try:
            from app.utils.api import post_raw
            r = post_raw(url, {"content": "✅ Test webhook từ Golike Tool", "username": "Job Ảo Monitor"})
            if r.status_code in (200, 204):
                safe_print(f"{Colors.GREEN}✓ Gửi thành công!{Colors.RESET}")
            else:
                safe_print(f"{Colors.RED}HTTP {r.status_code}{Colors.RESET}")
        except Exception as e:
            safe_print(f"{Colors.RED}Lỗi: {e}{Colors.RESET}")


def show_current_config():
    safe_print(f"\n{Colors.BOLD_WHITE}── config.json ──{Colors.RESET}")
    safe_print(f"  {Colors.CYAN}token        {Colors.WHITE}= {mask(CONFIG.get('token', ''))}")
    safe_print(f"  {Colors.CYAN}signing_key  {Colors.WHITE}= {mask(CONFIG.get('signing_key', ''), 6)}")
    safe_print(f"  {Colors.CYAN}user_id      {Colors.WHITE}= {Colors.YELLOW}{CONFIG.get('user_id', 0)}")
    safe_print(f"  {Colors.CYAN}username     {Colors.WHITE}= {Colors.YELLOW}{CONFIG.get('username', '')}")
    safe_print(f"  {Colors.CYAN}device_id    {Colors.WHITE}= {Colors.YELLOW}{CONFIG.get('device_id', '')}")
    safe_print(f"  {Colors.CYAN}webhook_url  {Colors.WHITE}= {mask(CONFIG.get('webhook_url', ''), keep=20)}")
    safe_print(f"  {Colors.CYAN}so_luong_job {Colors.WHITE}= {Colors.YELLOW}{CONFIG['so_luong_job']}")
    safe_print(f"  {Colors.CYAN}delay_giay   {Colors.WHITE}= {Colors.YELLOW}{CONFIG['delay_giay']}")
    safe_print(f"  {Colors.CYAN}dung_sau_loi {Colors.WHITE}= {Colors.YELLOW}{CONFIG['dung_sau_loi']}")
    safe_print(f"{Colors.CYAN}  File: {os.path.abspath('config.json')}{Colors.RESET}")


def configure_menu():
    while True:
        idx = ask_choice(
            "Cấu hình:",
            [
                "GolikeAuth (5 trường)",
                "Discord Webhook",
                "Job settings (số job / delay / max errors)",
                "Xem toàn bộ config hiện tại",
                "Quay lại menu chính",
            ],
        )
        if idx in (-1, 4):
            return
        if idx == 0:
            configure_auth()
        elif idx == 1:
            configure_webhook()
        elif idx == 2:
            configure_jobs()
        elif idx == 3:
            show_current_config()


# ===========================================================================
# Tính năng
# ===========================================================================
def feature_single_account(auth: GolikeAuth):
    runner = SingleAccountRunner(auth)

    idx = ask_choice(
        "Chạy 1 account:",
        [
            "Chạy tất cả platforms (vòng lặp vô hạn)",
            "Chọn 1 platform cụ thể",
            "Chỉ liệt kê accounts (không chạy job)",
            "Xem profile",
        ],
    )
    if idx == -1:
        return
    if idx == 3:
        runner.show_profile()
    elif idx == 2:
        runner.list_accounts()
    elif idx == 1:
        platform_idx = ask_choice(
            "Chọn platform:",
            [(name, None) for name, _ in ALL_PROVIDERS],
        )
        if platform_idx != -1:
            runner.run(only_platform=ALL_PROVIDERS[platform_idx][0])
    else:  # idx == 0
        runner.run()


def feature_multi_account():
    if not os.path.exists(FILE_AUTH):
        safe_print(f"{Colors.RED}Không tìm thấy {FILE_AUTH}!{Colors.RESET}")
        safe_print(f"{Colors.YELLOW}Tạo file {FILE_AUTH}, mỗi dòng 1 JWT token.{Colors.RESET}")
        return
    if not get_webhook():
        safe_print(f"{Colors.YELLOW}⚠ Chưa cấu hình Discord Webhook — multi mode sẽ KHÔNG gửi report.{Colors.RESET}")
        if ask("Vào cấu hình webhook ngay? (y/N)", "n").lower() == "y":
            configure_webhook()
    JobaoController().run()


def feature_profile(auth: GolikeAuth):
    SingleAccountRunner(auth).show_profile()


def feature_list_accounts(auth: GolikeAuth):
    runner = SingleAccountRunner(auth)
    if runner.show_profile():
        runner.list_accounts()


# ===========================================================================
# Menu chính
# ===========================================================================
def main_menu(auth: GolikeAuth):
    while True:
        idx = ask_choice(
            "Chọn tính năng:",
            [
                "Chạy 1 account (single mode)",
                "Chạy multi-account từ au.txt (multi-thread)",
                "Xem profile",
                "Liệt kê accounts của từng platform",
                "Cấu hình (GolikeAuth / Webhook / Jobs)",
            ],
            allow_back=False,
        )
        if idx == 0:
            feature_single_account(auth)
        elif idx == 1:
            feature_multi_account()
        elif idx == 2:
            feature_profile(auth)
        elif idx == 3:
            feature_list_accounts(auth)
        elif idx == 4:
            configure_menu()


def main():
    show_banner()
    try:
        auth = setup_on_first_run()
        safe_print(f"\n{Colors.GREEN}→ Vào menu chính...{Colors.RESET}")
        main_menu(auth)
    except KeyboardInterrupt:
        safe_print(f"\n{Colors.BOLD_YELLOW}Thoát.{Colors.RESET}")


if __name__ == "__main__":
    main()
