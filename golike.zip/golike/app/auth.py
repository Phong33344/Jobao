"""
app/auth.py - GolikeAuth dataclass + HTTP client methods.

Schema 5 trường (theo README §Quick start):
    GolikeAuth(
        token="eyJ...",               # JWT Bearer
        signing_key="...",            # browser: store.state.signing_key
        user_id=123456,
        username="your_username",
        device_id="32484704-...",     # UUID v4, nên giữ cố định
    )

Có 3 cách tạo:
    1. Tương tác:  GolikeAuth.prompt()        — hỏi user từng field
    2. Từ config:   GolikeAuth.from_config()  — đọc config.json
    3. Lưu lại:     auth.save_to_config()     — ghi xuống config.json

HTTP methods (mỗi lần gọi sẽ tạo g-auth MỚI):
    auth.headers(method, path, body=...)  -> dict
    auth.get(path, params=...)            -> dict | None
    auth.post(path, json=...)             -> dict | None
    auth.request(method, path, ...)       -> dict | None
    auth.put(path, ...)                   -> dict | None
    auth.patch(path, ...)                 -> dict | None
    auth.delete(path, ...)                -> dict | None
"""
import json
import re
from dataclasses import dataclass, asdict
from typing import Optional

from app.gauth import (
    encrypt_g_auth,
    make_t_header,
    get_g_version,
    G_CLIENT,
    normalize_body,
    generate_device_id,
    parse_signing_key,
)
from app.utils.config import (
    CONFIG,
    set_field,
    init_config_if_missing,
)


# ==============================================================================
# Base URL + UA
# ==============================================================================
BASE_URL = "https://gateway.golike.net/api"

USER_AGENT = (
    "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36"
)


# ==============================================================================
# Validation helpers
# ==============================================================================
# JWT format: header.payload.signature — mỗi phần là base64url
_JWT_RE = re.compile(r"^[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+$")


def _looks_like_jwt(token: str) -> bool:
    """Kiểm tra token có 3 phần ngăn bởi dấu chấm không (định dạng JWT chuẩn)."""
    return bool(token and _JWT_RE.match(token.strip()))


@dataclass
class GolikeAuth:
    """Bộ 5 trường bắt buộc + HTTP client."""

    token: str            # JWT Bearer (Authorization)
    signing_key: str      # 32 bytes, Base64/Hex/Base64URL
    user_id: int          # int
    username: str         # string
    device_id: str        # UUID v4 (giữ cố định)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------
    def __post_init__(self):
        if not self.token:
            raise ValueError("GolikeAuth.token rỗng")
        if not _looks_like_jwt(self.token):
            raise ValueError(
                "GolikeAuth.token KHÔNG đúng định dạng JWT "
                "(phải có 3 phần header.payload.signature ngăn bởi dấu chấm)."
            )
        if not self.signing_key:
            raise ValueError("GolikeAuth.signing_key rỗng")
        parse_signing_key(self.signing_key)  # raise nếu không decode được 32B
        if not isinstance(self.user_id, int) or self.user_id <= 0:
            raise ValueError(f"GolikeAuth.user_id phải là số dương, nhận: {self.user_id!r}")
        if not self.username:
            raise ValueError("GolikeAuth.username rỗng")
        if not self.device_id:
            self.device_id = generate_device_id()

    @classmethod
    def empty(cls) -> "GolikeAuth":
        """Tạo GolikeAuth rỗng, BỎ QUA validation. Chỉ dùng làm default placeholder."""
        obj = cls.__new__(cls)
        obj.token = ""
        obj.signing_key = ""
        obj.user_id = 0
        obj.username = ""
        obj.device_id = ""
        return obj

    # ==================================================================
    # HTTP CLIENT METHODS — mỗi request sinh g-auth MỚI
    # ==================================================================
    def headers(self, method: str, path: str, body=None) -> dict:
        """
        Sinh headers ĐẦY ĐỦ cho 1 request, gồm g-auth đã ký với method/path/body.

        Mỗi lần gọi sẽ tạo IV, nonce, timestamp MỚI → g-auth KHÔNG reuse được.
        """
        body_str = normalize_body(body) if body is not None else ""

        # Ký g-auth MỚI với method/path/body cụ thể
        g_auth = encrypt_g_auth(
            method=method,
            path=path,
            body=body_str,
            signing_key=self.signing_key,
            device_id=self.device_id,
            user_id=self.user_id,
        )

        return {
            "accept": "application/json, text/plain, */*",
            "accept-language": "vi,en-US;q=0.9,en;q=0.8",
            "authorization": f"Bearer {self.token}",
            "t": make_t_header(),
            "g-auth": g_auth,  # MỚI mỗi request
            "g-device-id": self.device_id,
            "g-username": self.username,
            "g-version": get_g_version(),  # mặc định 26.07.10.2
            "g-client": G_CLIENT,  # 109096667105508
            "content-type": "application/json;charset=utf-8",
            "origin": "https://app.golike.net",
            "referer": "https://app.golike.net/",
            "user-agent": USER_AGENT,
            "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
        }

    def request(self, method: str, path: str, params=None, json_body=None) -> dict:
        """Gửi request bất kỳ. Trả về parsed JSON (dict) hoặc None nếu lỗi."""
        try:
            from urllib.parse import urlencode
            from app.utils.api import _curl_requests as _req

            url_path = path
            if params:
                url_path = f"{path}?{urlencode(params)}"
            url = f"{BASE_URL}{url_path}"

            method_upper = method.upper()
            body_for_sign = json_body if json_body is not None else None
            headers = self.headers(method_upper, path, body=body_for_sign)

            if json_body is not None:
                body_str = json.dumps(json_body, separators=(",", ":"), ensure_ascii=False)
                resp = _req.request(
                    method_upper, url,
                    headers=headers,
                    data=body_str.encode("utf-8"),
                    impersonate="chrome",
                )
            else:
                resp = _req.request(
                    method_upper, url,
                    headers=headers,
                    impersonate="chrome",
                )
            return resp.json()
        except Exception as e:
            from app.ui import Colors, safe_print
            safe_print(f"{Colors.RED}{method.upper()} {path} error: {e}{Colors.RESET}")
            return None

    # Shortcut methods
    def get(self, path: str, params=None) -> dict:
        return self.request("GET", path, params=params)

    def post(self, path: str, json_body: dict = None) -> dict:
        return self.request("POST", path, json_body=json_body or {})

    def verify_signing_key(self) -> dict:
        """
        POST /security/echo — kiểm tra signing_key có decrypt được trên server không.
        Trả về {ok: bool, errors: list, message: str}.
        """
        try:
            from app.utils.api import _curl_requests as _req

            body = json.dumps({"ping": 1}, separators=(",", ":"))
            headers = self.headers("POST", "/security/echo", body=body)
            # chrome120 ổn định hơn "chrome" (tránh response lạ / empty gauth)
            last_err = None
            data = None
            for imp in ("chrome120", "chrome110", "chrome"):
                try:
                    resp = _req.post(
                        f"{BASE_URL}/security/echo",
                        headers=headers,
                        data=body.encode("utf-8"),
                        impersonate=imp,
                        timeout=30,
                    )
                    data = resp.json()
                    break
                except Exception as e:
                    last_err = e
                    continue
            if data is None:
                return {
                    "ok": False,
                    "errors": [str(last_err)],
                    "message": f"Khong goi duoc /security/echo: {last_err}",
                }

            # Rate limit / loi khac
            code = data.get("code") or data.get("status")
            msg = str(data.get("message") or data.get("error") or "")
            if code == 429 or "429" in msg or "qua nhanh" in msg.lower():
                return {
                    "ok": False,
                    "errors": ["rate_limit_429"],
                    "raw_status": code,
                    "message": "Bi rate-limit (429). Doi 10-15s roi chay lai — KHONG phai signing_key sai.",
                }

            g = (data.get("data") or {}).get("gauth") if isinstance(data.get("data"), dict) else {}
            g = g or {}
            errs = list(g.get("errors") or [])
            decoded = g.get("decoded")
            decrypt_fail = any("decrypt" in str(e).lower() for e in errs)

            if decoded is not None and not decrypt_fail:
                return {
                    "ok": True,
                    "errors": errs,
                    "decoded": decoded,
                    "raw_status": data.get("status"),
                    "message": None,
                }

            if decrypt_fail or (
                g.get("header_present") and decoded is None and errs
            ):
                return {
                    "ok": False,
                    "errors": errs or ["decrypt_fail"],
                    "decoded": None,
                    "raw_status": data.get("status"),
                    "message": (
                        "signing_key SAI / het han — server decrypt_fail. "
                        "Lay lai tu browser: "
                        "document.querySelector('#app').__vue__.$store.state.signing_key"
                    ),
                }

            # Response khong co block gauth (echo bi chan / format la)
            return {
                "ok": False,
                "errors": errs or ["no_gauth_in_response"],
                "decoded": decoded,
                "raw_status": data.get("status"),
                "raw_keys": list(data.keys()),
                "message": (
                    "Khong doc duoc ket qua g-auth tu /security/echo "
                    f"(status={data.get('status')}, msg={msg[:80]!r}). "
                    "Thu lai sau vai giay; neu van fail hay check mang/proxy."
                ),
            }
        except Exception as e:
            return {"ok": False, "errors": [str(e)], "message": str(e)}

    def put(self, path: str, json_body: dict = None) -> dict:
        return self.request("PUT", path, json_body=json_body or {})

    def patch(self, path: str, json_body: dict = None) -> dict:
        return self.request("PATCH", path, json_body=json_body or {})

    def delete(self, path: str) -> dict:
        return self.request("DELETE", path)

    # ==================================================================
    # Persistence
    # ==================================================================
    def to_dict(self) -> dict:
        return asdict(self)

    def save_to_config(self) -> None:
        """Lưu 5 trường xuống config.json."""
        for k, v in self.to_dict().items():
            set_field(k, v)

    @classmethod
    def from_config(cls) -> Optional["GolikeAuth"]:
        """
        Đọc 5 trường từ config.json. Trả None nếu thiếu token/signing_key/user_id
        hoặc token KHÔNG đúng định dạng JWT.

        LUÔN reload file mỗi lần gọi (không dùng cache) — nếu user edit file
        bằng tay hoặc tool khác ghi, lần gọi sau sẽ thấy giá trị mới.
        """
        from app.utils.config import load_config  # local import tránh circular
        cfg = load_config()  # luôn đọc từ file, KHÔNG dùng CONFIG cached

        token = (cfg.get("token") or "").strip()
        signing_key = (cfg.get("signing_key") or "").strip()
        if not token or not signing_key:
            return None
        if not _looks_like_jwt(token):
            return None
        try:
            user_id = int(cfg.get("user_id") or 0)
        except (TypeError, ValueError):
            user_id = 0
        if user_id <= 0:
            return None
        try:
            return cls(
                token=token,
                signing_key=signing_key,
                user_id=user_id,
                username=(cfg.get("username") or "").strip() or "unknown",
                device_id=(cfg.get("device_id") or "").strip() or generate_device_id(),
            )
        except ValueError:
            return None

    # ==================================================================
    # Interactive prompt
    # ==================================================================
    @classmethod
    def prompt(
        cls,
        existing: Optional["GolikeAuth"] = None,
        force_all: bool = False,
    ) -> "GolikeAuth":
        """Hỏi user từng field. Enter = giữ default từ `existing` (nếu có)."""
        from app.ui import Colors, safe_print, ask

        safe_print(f"\n{Colors.BOLD_WHITE}{'='*60}{Colors.RESET}")
        safe_print(f"{Colors.BOLD_CYAN}  Khai báo GolikeAuth (5 trường bắt buộc){Colors.RESET}")
        safe_print(f"{Colors.BOLD_WHITE}{'='*60}{Colors.RESET}")

        def ask_field(label: str, hint: str, current: str = "",
                      validator=None, invalid_msg: str = "không hợp lệ") -> str:
            """Hỏi 1 field. Nếu có validator, loop hỏi lại khi value invalid."""
            if current and not force_all:
                safe_print(f"  {Colors.CYAN}{label}{Colors.RESET}: "
                           f"{Colors.YELLOW}{_mask(current)}{Colors.RESET}  "
                           f"{Colors.WHITE}(Enter = giữ){Colors.RESET}")
                val = ask(f"    {hint}", "")
                candidate = val.strip() or current
                if validator and not validator(candidate):
                    safe_print(f"    {Colors.RED}{invalid_msg}{Colors.RESET}")
                    # Recurse vào chế độ bắt buộc nhập
                    return ask_field(label, hint, current="",
                                     validator=validator, invalid_msg=invalid_msg)
                return candidate

            safe_print(f"  {Colors.CYAN}{label}{Colors.RESET}: {Colors.WHITE}{hint}{Colors.RESET}")
            while True:
                val = ask(f"    Nhập {label}", "")
                candidate = val.strip()
                if not candidate:
                    safe_print(f"    {Colors.RED}{label} không được rỗng.{Colors.RESET}")
                    continue
                if validator and not validator(candidate):
                    safe_print(f"    {Colors.RED}{invalid_msg}{Colors.RESET}")
                    continue
                return candidate

        old = existing if existing is not None else GolikeAuth.empty()

        # 1. token — validate JWT format
        token = ask_field(
            "token (JWT Bearer)",
            "eyJhbGciOiJIUzI1NiIs.payload.signature",
            current=(old.token if existing else ""),
            validator=_looks_like_jwt,
            invalid_msg="token KHÔNG đúng định dạng JWT (phải có 3 phần ngăn bởi dấu chấm, vd eyJ....xxx.yyy)",
        )

        # 2. signing_key
        signing_key = ask_field(
            "signing_key (Base64 32B)",
            "lấy từ DevTools: $store.state.signing_key trong browser console",
            current=(old.signing_key if existing else ""),
        )

        # 3. user_id
        if existing and not force_all:
            safe_print(f"  {Colors.CYAN}user_id{Colors.RESET}: "
                       f"{Colors.YELLOW}{old.user_id}{Colors.RESET}  "
                       f"{Colors.WHITE}(Enter = giữ){Colors.RESET}")
            uid_raw = ask("    Nhập user_id (số nguyên)", "")
            user_id = int(uid_raw) if uid_raw.strip() else old.user_id
        else:
            while True:
                uid_raw = ask("    Nhập user_id (số nguyên)", "")
                try:
                    user_id = int(uid_raw.strip())
                    if user_id > 0:
                        break
                except ValueError:
                    pass
                safe_print(f"    {Colors.RED}user_id phải là số nguyên dương.{Colors.RESET}")

        # 4. username
        username = ask_field(
            "username",
            "tên đăng nhập Golike của bạn",
            current=(old.username if existing else ""),
        )

        # 5. device_id
        if existing and not force_all and old.device_id:
            safe_print(f"  {Colors.CYAN}device_id{Colors.RESET}: "
                       f"{Colors.YELLOW}{old.device_id}{Colors.RESET}  "
                       f"{Colors.WHITE}(Enter = giữ — nên giữ cố định){Colors.RESET}")
            dev_raw = ask("    Nhập device_id (UUID)", "")
            device_id = dev_raw.strip() or old.device_id
        else:
            suggestion = generate_device_id()
            safe_print(f"  {Colors.CYAN}device_id{Colors.RESET}: "
                       f"{Colors.WHITE}gợi ý (nên giữ cố định): "
                       f"{Colors.YELLOW}{suggestion}{Colors.RESET}")
            dev_raw = ask("    Nhập device_id (Enter = dùng gợi ý)", suggestion)
            device_id = dev_raw.strip() or suggestion

        auth = cls(
            token=token, signing_key=signing_key,
            user_id=user_id, username=username, device_id=device_id,
        )

        safe_print(f"\n{Colors.BOLD_GREEN}{'─'*60}{Colors.RESET}")
        safe_print(f"  {Colors.BOLD_CYAN}Đã nhận GolikeAuth:{Colors.RESET}")
        safe_print(f"    token      = {_mask(auth.token)}")
        safe_print(f"    signing_key= {_mask(auth.signing_key, 6)}")
        safe_print(f"    user_id    = {Colors.YELLOW}{auth.user_id}{Colors.RESET}")
        safe_print(f"    username   = {Colors.YELLOW}{auth.username}{Colors.RESET}")
        safe_print(f"    device_id  = {Colors.YELLOW}{auth.device_id}{Colors.RESET}")
        safe_print(f"{Colors.BOLD_GREEN}{'─'*60}{Colors.RESET}")

        return auth


def _mask(s: str, keep: int = 8) -> str:
    if not s:
        return "(rỗng)"
    if len(s) <= keep * 2:
        return s[:4] + "..." + s[-4:]
    return s[:keep] + "..." + s[-keep:]
