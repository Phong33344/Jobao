"""
app/controllers.py - JobaoController: orchestration + Discord webhook reporter.

Multi-account flow:
    - au.txt chứa NHIỀU JWT (mỗi dòng 1 token) — đăng nhập nhiều session
    - signing_key, user_id, username, device_id: DÙNG CHUNG từ config
      (vì đây là thuộc tính của 1 user, không phải của 1 session)
    - Mỗi worker tạo 1 GolikeAuth riêng bằng cách ghép:
        base auth (từ config) + token (từ au.txt)
"""
import os
import time
import queue
import threading
from datetime import datetime
from typing import List, Dict

from app.auth import GolikeAuth
from app.utils.api import post_raw, patch_raw
from app.ui import Colors, safe_print, show_banner
from app.utils.config import CONFIG, get_webhook
from app.workers import WorkerThread


FILE_AUTH = 'au.txt'


class JobaoController:
    REPORT_INTERVAL = 600  # 10 phút

    def __init__(self):
        self.workers: List[WorkerThread] = []
        self.stats_queue: queue.Queue = queue.Queue()
        self.running = True
        self.message_id = None
        self.webhook_url: str = get_webhook()

    # ---------- tokens ----------
    def load_auth_tokens(self) -> List[str]:
        """Đọc au.txt — mỗi dòng = 1 JWT token. Bỏ qua dòng rỗng / comment (#)."""
        tokens: List[str] = []
        if not os.path.exists(FILE_AUTH):
            safe_print(f"{Colors.RED}File {FILE_AUTH} not found!{Colors.RESET}")
            return tokens
        with open(FILE_AUTH, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    tokens.append(line)
        return tokens

    def build_auth_for_token(self, token: str) -> GolikeAuth:
        """
        Ghép base auth (từ config) + token (từ au.txt) → 1 GolikeAuth hoàn chỉnh.
        """
        return GolikeAuth(
            token=token,
            signing_key=CONFIG['signing_key'],
            user_id=int(CONFIG['user_id']),
            username=CONFIG['username'],
            device_id=CONFIG['device_id'],
        )

    def start_workers(self):
        tokens = self.load_auth_tokens()
        if not tokens:
            safe_print(f"{Colors.RED}No valid authorization tokens found in {FILE_AUTH}{Colors.RESET}")
            return

        safe_print(f"{Colors.BOLD_GREEN}Starting {len(tokens)} worker(s)...{Colors.RESET}")
        for idx, token in enumerate(tokens):
            try:
                auth = self.build_auth_for_token(token)
            except ValueError as e:
                safe_print(f"{Colors.RED}Token #{idx+1}: không tạo được GolikeAuth ({e}) — bỏ qua{Colors.RESET}")
                continue
            worker = WorkerThread(auth, idx + 1, self.stats_queue)
            worker.start()
            self.workers.append(worker)
            time.sleep(1)

    # ---------- stats ----------
    def collect_stats(self) -> Dict[int, Dict]:
        stats_dict: Dict[int, Dict] = {}
        while not self.stats_queue.empty():
            try:
                worker_id, stats = self.stats_queue.get_nowait()
                stats_dict[worker_id] = stats
            except queue.Empty:
                break
        return stats_dict

    # ---------- discord webhook ----------
    def _build_embed(self, stats_dict: Dict[int, Dict]) -> dict:
        total_workers = len(self.workers)
        active_workers = sum(1 for s in stats_dict.values() if s['status'] == 'active')
        dead_workers = total_workers - active_workers

        total_earned = sum(s['total_earned'] for s in stats_dict.values())
        total_coin = sum(s['coin'] for s in stats_dict.values())
        jobs_done = sum(s['jobs_done'] for s in stats_dict.values())

        description_lines = []
        for wid, s in stats_dict.items():
            status_emoji = "🟢" if s['status'] == 'active' else "🔴"
            description_lines.append(
                f"{status_emoji} **Worker {wid}** - `{s['username']}`\n"
                f"   Coin: {s['coin']} | Earned: {s['total_earned']} | Jobs: {s['jobs_done']}\n"
                f"   Status: {s['status']}"
            )

        return {
            "title": "📊 Golike Multi-Account Status",
            "description": "\n".join(description_lines) if description_lines else "No data",
            "color": 5814783,
            "fields": [
                {"name": "Active Workers", "value": f"{active_workers}/{total_workers}", "inline": True},
                {"name": "Total Coin", "value": f"{total_coin}", "inline": True},
                {"name": "Total Earned", "value": f"{total_earned}", "inline": True},
                {"name": "Jobs Completed", "value": f"{jobs_done}", "inline": True},
                {"name": "Dead Workers", "value": f"{dead_workers}", "inline": True},
            ],
            "footer": {"text": f"Last update: {datetime.now().strftime('%H:%M:%S')}"},
        }

    def send_webhook_report(self, stats_dict: Dict[int, Dict]):
        if not stats_dict or not self.webhook_url:
            return

        payload = {
            "content": None,
            "embeds": [self._build_embed(stats_dict)],
            "username": "Job Ảo Monitor",
        }

        try:
            if self.message_id:
                edit_url = f"{self.webhook_url}/messages/{self.message_id}"
                resp = patch_raw(edit_url, payload)
                if resp.status_code != 200:
                    resp = post_raw(self.webhook_url, payload)
                    if resp.status_code == 200:
                        self.message_id = resp.json().get('id')
            else:
                resp = post_raw(self.webhook_url, payload)
                if resp.status_code == 200:
                    self.message_id = resp.json().get('id')
        except Exception as e:
            safe_print(f"{Colors.RED}Webhook error: {e}{Colors.RESET}")

    # ---------- monitor ----------
    def monitor_loop(self):
        last_report = 0
        while self.running:
            time.sleep(10)
            stats = self.collect_stats()
            now = time.time()
            if now - last_report >= self.REPORT_INTERVAL:
                self.send_webhook_report(stats)
                last_report = now

    # ---------- lifecycle ----------
    def stop(self):
        self.running = False
        for w in self.workers:
            w.stop()
        for w in self.workers:
            w.join(timeout=5)
        safe_print(f"{Colors.YELLOW}All workers stopped.{Colors.RESET}")

    def run(self):
        show_banner()
        safe_print(
            f"{Colors.BOLD_GREEN}Configuration: "
            f"{CONFIG['so_luong_job']} jobs per platform | "
            f"Delay: {CONFIG['delay_giay']}s | "
            f"Max errors: {CONFIG['dung_sau_loi']}{Colors.RESET}"
        )
        self.start_workers()
        if not self.workers:
            return

        monitor_thread = threading.Thread(target=self.monitor_loop, daemon=True)
        monitor_thread.start()

        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            safe_print(f"\n{Colors.BOLD_YELLOW}Shutting down...{Colors.RESET}")
            self.stop()
            stats = self.collect_stats()
            self.send_webhook_report(stats)
