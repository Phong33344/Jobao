"""
app/__init__.py - Package chứa toàn bộ logic của tool.
main.py (ở root) import từ đây:
    from app.ui import Colors, safe_print
    from app.providers import TwitterBot, ...
    from app.utils import CONFIG

Import app.utils.config ở đây để đảm bảo config.json auto-được tạo
ngay khi package được load.
"""
from app.utils import config as _config  # noqa: F401
