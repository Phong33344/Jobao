"""
app/utils/api.py - HTTP client cho mỗi request tới gateway.golike.net.

Mỗi request tự động ký g-auth MỚI (qua GolikeAuth.headers()).
Provider code gọi các hàm này thay vì tự build headers.

Lưu ý quan trọng:
    - GET / HEAD / DELETE → body ký = ""
    - POST / PUT / PATCH  → body ký = JSON compact, gửi đúng bytes đã ký
    - Path ký = pathname có prefix "/api/..." (KHÔNG có query)
    - g-auth sinh MỚI mỗi request (qua encrypt_g_auth → IV + nonce + timestamp mới)
"""
import os
import sys
import subprocess

try:
    from curl_cffi import requests
except ImportError:
    print("[utils.api] curl_cffi not installed, installing...", flush=True)
    subprocess.check_call([sys.executable, "-m", "pip", "install", "curl_cffi"])
    from curl_cffi import requests  # noqa: E402

# Re-export cho app.auth.GolikeAuth.request() dùng
_curl_requests = requests


# ==============================================================================
# Provider-friendly wrappers (mỗi lần gọi sẽ tạo g-auth MỚI qua auth.get/post)
# ==============================================================================
def get(auth, path: str, params=None):
    """
    GET request tới gateway. Ký g-auth mới cho method=GET, body="".

    Args:
        auth: GolikeAuth (5 trường bắt buộc)
        path: vd "/advertising/publishers/twitter/jobs"
        params: query dict (vd {"account_id": "123"})
    """
    return auth.get(path, params=params)


def post(auth, path: str, json_body=None):
    """
    POST JSON tới gateway. Ký g-auth mới với method=POST và body=JSON compact.
    Bytes gửi đi phải KHỚP 100% với body đã ký trong g-auth.
    """
    return auth.post(path, json_body=json_body or {})


def get_me(auth):
    """GET /users/me — lấy thông tin user hiện tại."""
    return auth.get("/users/me")


# ==============================================================================
# Raw (cho Discord webhook, KHÔNG ký g-auth)
# ==============================================================================
def post_raw(url: str, json_body: dict):
    return requests.post(url, json=json_body, impersonate="chrome")


def patch_raw(url: str, json_body: dict):
    return requests.patch(url, json=json_body, impersonate="chrome")


# ==============================================================================
# Backward-compat: make_headers (giữ API cũ cho code cũ)
# ==============================================================================
def make_headers(auth, method: str, path: str, body=None) -> dict:
    """
    DEPRECATED — dùng auth.headers(method, path, body) trực tiếp.
    Vẫn export để code cũ không break.
    """
    return auth.headers(method, path, body=body)
