"""
app/utils/config.py - Quản lý config.json (GolikeAuth + webhook + jobs settings).

Schema mới:
    {
        # GolikeAuth (5 trường bắt buộc)
        "token":        "",
        "signing_key":  "",
        "user_id":      0,
        "username":     "",
        "device_id":    "",

        # Discord webhook
        "webhook_url":  "",

        # Job settings
        "so_luong_job": 1000,
        "delay_giay":   5,
        "dung_sau_loi": 5,
    }

Schema cũ (auth_token/t_token) sẽ tự động migrate → schema mới khi load.
"""
import os
import json


FILE_CONFIG = 'config.json'

# Marker fields để phát hiện schema cũ
_LEGACY_KEYS = {"auth_token", "t_token"}

DEFAULT_CONFIG = {
    # GolikeAuth (5 trường bắt buộc)
    "token": "",
    "signing_key": "",
    "user_id": 0,
    "username": "",
    "device_id": "",
    # Discord webhook (rỗng = tắt)
    "webhook_url": "",
    # Job settings
    "so_luong_job": 1000,
    "delay_giay": 5,
    "dung_sau_loi": 5,
}


def init_config_if_missing():
    """Tạo config.json từ DEFAULT_CONFIG nếu file chưa tồn tại."""
    if not os.path.exists(FILE_CONFIG):
        with open(FILE_CONFIG, 'w', encoding='utf-8') as f:
            json.dump(DEFAULT_CONFIG.copy(), f, indent=4, ensure_ascii=False)


def load_config():
    """Đọc config.json. Auto-create nếu chưa có. Migrate schema cũ → mới."""
    init_config_if_missing()
    try:
        with open(FILE_CONFIG, 'r', encoding='utf-8') as f:
            data = json.load(f)
        # Migrate schema cũ (auth_token/t_token) → schema mới
        if _LEGACY_KEYS & set(data.keys()):
            data = DEFAULT_CONFIG.copy()
            save_config(data)
            return data
        updated = False
        for k, v in DEFAULT_CONFIG.items():
            if k not in data:
                data[k] = v
                updated = True
        if updated:
            save_config(data)
        return data
    except Exception:
        save_config(DEFAULT_CONFIG.copy())
        return DEFAULT_CONFIG.copy()


def save_config(config: dict):
    """Ghi config ra file (overwrite)."""
    with open(FILE_CONFIG, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4, ensure_ascii=False)


# Khởi tạo file + load ngay khi module được import
init_config_if_missing()
CONFIG = load_config()


def set_field(key: str, value, config: dict = None):
    """Cập nhật 1 field và lưu xuống file. Trả về config mới."""
    cfg = config if config is not None else CONFIG
    cfg[key] = value
    save_config(cfg)
    return cfg


def has_auth(config: dict = None) -> bool:
    """Kiểm tra config đã có đủ token + signing_key + user_id chưa."""
    cfg = config if config is not None else CONFIG
    token = (cfg.get("token") or "").strip()
    sk = (cfg.get("signing_key") or "").strip()
    try:
        uid = int(cfg.get("user_id") or 0)
    except (TypeError, ValueError):
        uid = 0
    return bool(token) and bool(sk) and uid > 0


def get_webhook(config: dict = None) -> str:
    """Lấy webhook_url (đã strip). Rỗng = tắt."""
    cfg = config if config is not None else CONFIG
    return (cfg.get("webhook_url") or "").strip()
