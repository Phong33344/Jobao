"""
app/utils/__init__.py - Re-export tiện ích cho code ngoài.
    from app.utils import CONFIG, make_headers, get_me, post_raw, patch_raw
"""
from app.utils.api import (
    make_headers,
    get,
    post,
    get_me,
    post_raw,
    patch_raw,
)
from app.utils.config import (
    FILE_CONFIG,
    DEFAULT_CONFIG,
    CONFIG,
    load_config,
    save_config,
    init_config_if_missing,
    set_field,
    has_auth,
    get_webhook,
)
# BASE_URL & USER_AGENT giờ ở app/auth.py (vì GolikeAuth dùng cho HTTP client methods)
from app.auth import BASE_URL, USER_AGENT

__all__ = [
    "BASE_URL",
    "USER_AGENT",
    "make_headers",
    "get",
    "post",
    "get_me",
    "post_raw",
    "patch_raw",
    "FILE_CONFIG",
    "DEFAULT_CONFIG",
    "CONFIG",
    "load_config",
    "save_config",
    "init_config_if_missing",
    "set_field",
    "has_auth",
    "get_webhook",
]
