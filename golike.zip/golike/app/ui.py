"""
app/ui.py - Console UI utilities (colors, banner, input helpers, countdown).

Dùng chung cho mọi module:
    from app.ui import Colors, safe_print, ask, ask_choice, mask, countdown, show_banner
"""
import os
import sys
import time
import threading
from datetime import datetime


# ==============================================================================
# COLORS
# ==============================================================================
class Colors:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    BOLD_RED = '\033[1;31m'
    BOLD_GREEN = '\033[1;32m'
    BOLD_YELLOW = '\033[1;33m'
    BOLD_BLUE = '\033[1;34m'
    BOLD_CYAN = '\033[1;36m'
    BOLD_WHITE = '\033[1;37m'
    MAGENTA = '\033[35m'
    BOLD_MAGENTA = '\033[1;35m'


# Global lock for console printing (thread-safe)
print_lock = threading.Lock()


def safe_print(*args, **kwargs):
    """Thread-safe print."""
    with print_lock:
        print(*args, **kwargs)


def show_banner():
    """In banner đầu tool."""
    os.system("cls" if os.name == "nt" else "clear")
    banner = f"""
{Colors.BOLD_CYAN}╔════════════════════════════════════════════════════════════════════════╗
{Colors.BOLD_CYAN}║{Colors.BOLD_WHITE}                       ⛃  BÉ TẬP CODE TOOL  ⛃                        {Colors.BOLD_CYAN}║
{Colors.BOLD_CYAN}╠════════════════════════════════════════════════════════════════════════╣
{Colors.BOLD_CYAN}║ {Colors.BOLD_YELLOW}⛃  TOOL BY       {Colors.BOLD_WHITE}: ThanhBinh Tool                                     {Colors.BOLD_CYAN}║
{Colors.BOLD_CYAN}║ {Colors.BOLD_YELLOW}⛃  VERSION       {Colors.BOLD_WHITE}: Professional v1.0                    {Colors.BOLD_CYAN}║
{Colors.BOLD_CYAN}║ {Colors.BOLD_YELLOW}⛃  DATE          {Colors.BOLD_WHITE}: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}                             {Colors.BOLD_CYAN}║
{Colors.BOLD_CYAN}╚════════════════════════════════════════════════════════════════════════╝{Colors.RESET}
"""
    safe_print(banner)


def countdown(seconds: int, message: str = "Waiting"):
    """Đếm ngược có khóa thread-safe để nhiều worker không in đè lên nhau."""
    for remaining in range(seconds, -1, -1):
        with print_lock:
            sys.stdout.write(f"\r{Colors.BOLD_CYAN}[{message}] {Colors.BOLD_YELLOW}{remaining}s... {Colors.RESET}")
            sys.stdout.flush()
        time.sleep(1)
    with print_lock:
        print("\r" + " " * 60 + "\r", end="")


# ==============================================================================
# INPUT HELPERS (dùng cho cả main.py và app/auth.py)
# ==============================================================================
def ask(prompt: str, default: str = "") -> str:
    """
    Hỏi user nhập 1 dòng. Enter = dùng default (nếu có).
    Trả về chuỗi đã strip.
    EOFError / Ctrl+C → thoát chương trình sạch.
    """
    suffix = f" [{default}]" if default else ""
    try:
        val = input(f"{Colors.BOLD_CYAN}{prompt}{suffix}: {Colors.RESET}").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        sys.exit(0)
    return val or default


def ask_choice(prompt: str, options, allow_back: bool = True) -> int:
    """
    In menu các option, hỏi user chọn. Trả về index 0-based, hoặc -1 nếu back.

    Args:
        prompt: câu hỏi
        options: list các label string
        allow_back: True = cho phép chọn 0 để quay lại
    """
    safe_print(f"\n{Colors.BOLD_WHITE}{prompt}{Colors.RESET}")
    for i, label in enumerate(options, start=1):
        safe_print(f"  {Colors.BOLD_CYAN}{i}{Colors.RESET}. {label}")
    if allow_back:
        safe_print(f"  {Colors.BOLD_CYAN}0{Colors.RESET}. {Colors.YELLOW}← Quay lại{Colors.RESET}")

    while True:
        raw = ask("Chọn", "0" if allow_back else "1")
        try:
            n = int(raw)
        except ValueError:
            safe_print(f"{Colors.RED}Vui lòng nhập số.{Colors.RESET}")
            continue
        if allow_back and n == 0:
            return -1
        if 1 <= n <= len(options):
            return n - 1
        safe_print(f"{Colors.RED}Lựa chọn không hợp lệ.{Colors.RESET}")


def mask(s: str, keep: int = 8) -> str:
    """Che giấu string khi hiển thị: 'abcd1234...xyz'. Trả về chuỗi CÓ màu."""
    if not s:
        return f"{Colors.YELLOW}(rỗng){Colors.RESET}"
    if len(s) <= keep * 2:
        return s[:4] + "..." + s[-4:]
    return s[:keep] + "..." + s[-keep:]
