"""
app/gauth.py - Mã hoá / giải mã header g-auth (Golike Gateway).

Spec (theo README §4-§7):
    signing_key (Base64URL/Hex) ─decode 32B─▶ IKM
       └─HKDF-SHA256(salt="glk-gauth-v3-2026q3", info="aes-gcm-key", len=32)─▶ AES_KEY
    payload = {t, x, d, u, n, k, q, r}
        t: Date.now() ms
        x: 16B random → Base64URL (no padding)
        d: device_id UUID
        u: user_id
        n: method upper
        k: pathname (có prefix /api/...)
        q: SHA256_hex(body_str) — body_str là chuỗi rỗng "" cho GET
        r: SHA256_hex(f"{t}:{device_id}:{q}:{SALT}")[:16]
    ciphertext = AES-256-GCM(key, IV=12B random, payload_utf8)
    g_auth     = Base64URL(IV || ciphertext+tag)

Header `t` (ngoài AES):
    t_header = btoa(btoa(btoa(str(unix_seconds))))
"""
import base64
import hashlib
import hmac
import json
import secrets
import time
import uuid
from datetime import datetime
from typing import Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes


# ==============================================================================
# CONSTANTS (theo README)
# ==============================================================================
SALT = "glk-gauth-v3-2026q3"  # HKDF salt
INFO = "aes-gcm-key"           # HKDF info

# Header g-client / g-version PHẢI khớp app web (index-68ef440b.js: Pt(182)/Pt(192)).
# Sai → 403 "Vui lòng cập nhật phiên bản mới nhất..."
G_CLIENT = "109096667105508"
_DEFAULT_G_VERSION = "26.07.10.2"

import os as _os


def get_g_version() -> str:
    """
    Header g-version.
    Ưu tiên: config.json > env GOLIKE_G_VERSION > default app web (26.07.10.2).

    KHÔNG auto-gen theo ngày — server check đúng build app.
    """
    try:
        from app.utils.config import CONFIG
        v = (CONFIG.get("g_version") or "").strip()
        if v:
            return v
    except Exception:
        pass

    env_v = _os.environ.get("GOLIKE_G_VERSION", "").strip()
    if env_v:
        return env_v

    return _DEFAULT_G_VERSION


# ==============================================================================
# Helpers
# ==============================================================================
def b64url_encode(data: bytes) -> str:
    """Base64URL không padding."""
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64url_decode(s: str) -> bytes:
    """Base64URL decode (tự thêm padding nếu thiếu)."""
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s.replace("-", "+").replace("_", "/") + pad)


def b64_encode(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def generate_device_id() -> str:
    """UUID v4 cho header g-device-id (nên giữ cố định)."""
    return str(uuid.uuid4())


def generate_nonce() -> str:
    """16 bytes random → Base64URL."""
    return b64url_encode(secrets.token_bytes(16))


# ==============================================================================
# signing_key parsing
# ==============================================================================
def parse_signing_key(raw: str) -> bytes:
    """
    Parse signing_key ra 32 bytes. Chấp nhận:
        - Base64 (có +, /, =): chuẩn
        - Base64URL (-, _, không padding)
        - Hex 64 ký tự

    Raises:
        ValueError: nếu không decode ra được 32 bytes.
    """
    if not raw:
        raise ValueError("signing_key rỗng")
    raw = raw.strip()
    s = raw

    # 1. Thử hex nếu đúng độ dài & chỉ chứa hex chars
    is_hex_candidate = (
        len(s) == 64
        and all(c in "0123456789abcdefABCDEF" for c in s)
    )
    if is_hex_candidate:
        try:
            decoded = bytes.fromhex(s)
            if len(decoded) == 32:
                return decoded
        except ValueError:
            pass

    # 2. Thử Base64 (chuẩn)
    try:
        decoded = base64.b64decode(s, validate=False)
        if len(decoded) == 32:
            return decoded
    except Exception:
        pass

    # 3. Thử Base64URL
    try:
        pad = "=" * (-len(s) % 4)
        decoded = base64.urlsafe_b64decode(s + pad)
        if len(decoded) == 32:
            return decoded
    except Exception:
        pass

    raise ValueError(
        "signing_key không decode ra được 32 bytes. "
        "Định dạng hợp lệ: Base64 (cxbbf6td1EXcoEWlnk0eVmJwG1NJYhiqPxNcUXG+cBc=) "
        "hoặc Hex 64 ký tự."
    )


# ==============================================================================
# HKDF + AES-GCM
# ==============================================================================
def derive_aes_key(signing_key_raw: str) -> bytes:
    """HKDF-SHA256(signing_key, salt=SALT, info=INFO, len=32) → AES_KEY."""
    ikm = parse_signing_key(signing_key_raw)
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=SALT.encode("utf-8"),
        info=INFO.encode("utf-8"),
    ).derive(ikm)


# ==============================================================================
# Path/body normalization
# ==============================================================================
def normalize_path(path: str, base_prefix: str = "/api") -> str:
    """
    Chuẩn hoá path để ký:
        - Bỏ query/hash
        - Bỏ leading slash, ghép với base_prefix
        - Trả về pathname dạng '/api/...'

    Ví dụ:
        normalize_path('/advertising/publishers/twitter/jobs?account_id=1')
            → '/api/advertising/publishers/twitter/jobs'
    """
    # Bỏ query & hash
    path = path.split("?", 1)[0].split("#", 1)[0]
    # Bỏ leading slash để ghép
    stripped = path.lstrip("/")
    if base_prefix and not stripped.startswith(base_prefix.strip("/") + "/") \
       and stripped != base_prefix.strip("/"):
        stripped = f"{base_prefix.strip('/')}/{stripped}" if stripped else base_prefix
    return "/" + stripped


def normalize_body(body) -> str:
    """
    Chuẩn hoá body để tính SHA256:
        - None / undefined → ""
        - str → chính nó
        - bytes → decode UTF-8 (best-effort)
        - dict/list → JSON compact (separators=(",", ":"))
    """
    if body is None:
        return ""
    if isinstance(body, str):
        return body
    if isinstance(body, (bytes, bytearray)):
        try:
            return bytes(body).decode("utf-8")
        except UnicodeDecodeError:
            return bytes(body).decode("utf-8", errors="replace")
    return json.dumps(body, separators=(",", ":"), ensure_ascii=False)


# ==============================================================================
# Core: encrypt / decrypt g-auth
# ==============================================================================
def build_payload(
    method: str,
    path: str,
    body_str: str,
    device_id: str,
    user_id: int,
    timestamp_ms: Optional[int] = None,
    nonce: Optional[str] = None,
) -> dict:
    """Xây dict payload theo đúng thứ tự key t,x,d,u,n,k,q,r."""
    t = timestamp_ms if timestamp_ms is not None else int(time.time() * 1000)
    x = nonce if nonce is not None else generate_nonce()
    n = method.upper()
    k = normalize_path(path)
    q = sha256_hex(body_str)
    r = sha256_hex(f"{t}:{device_id}:{q}:{SALT}")[:16]

    return {
        "t": t,
        "x": x,
        "d": device_id,
        "u": user_id,
        "n": n,
        "k": k,
        "q": q,
        "r": r,
    }


def encrypt_g_auth(
    method: str,
    path: str,
    body,
    signing_key: str,
    device_id: str,
    user_id: int,
) -> str:
    """
    Sinh header g-auth (Base64URL) cho 1 request.

    Args:
        method: "GET" / "POST" / ...
        path: pathname KHÔNG có query (vd '/api/advertising/.../jobs').
              Hàm sẽ tự normalize nếu truyền path có query.
        body: None / str / dict / bytes — sẽ được normalize.
        signing_key: 32B key (Base64/Hex/Base64URL).
        device_id: UUID (giữ cố định).
        user_id: int.
    """
    key = derive_aes_key(signing_key)
    body_str = normalize_body(body)
    payload = build_payload(method, path, body_str, device_id, user_id)
    pt = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    iv = secrets.token_bytes(12)
    ct = AESGCM(key).encrypt(iv, pt, None)  # ct + 16B tag
    return b64url_encode(iv + ct)


def decrypt_g_auth(token: str, signing_key: str) -> dict:
    """Giải mã g-auth (debug / server-side verify)."""
    key = derive_aes_key(signing_key)
    raw = b64url_decode(token)
    iv, ct = raw[:12], raw[12:]
    pt = AESGCM(key).decrypt(iv, ct, None)
    return json.loads(pt.decode("utf-8"))


# ==============================================================================
# Header `t` (timestamp 3 lớp Base64)
# ==============================================================================
def make_t_header(timestamp_sec: Optional[int] = None) -> str:
    """btoa(btoa(btoa(str(unix_seconds))))."""
    ts = timestamp_sec if timestamp_sec is not None else int(time.time())
    once = b64_encode(str(ts).encode("ascii"))
    twice = b64_encode(once.encode("ascii"))
    thrice = b64_encode(twice.encode("ascii"))
    return thrice


# ==============================================================================
# Self-test: round-trip
# ==============================================================================
def _selftest():
    """Test nội bộ: round-trip encrypt/decrypt + verify fields."""
    sk = "cxbbf6td1EXcoEWlnk0eVmJwG1NJYhiqPxNcUXG+cBc="  # base64 32B
    dev = "32484704-8a4e-4909-9d42-866773b321d6"
    uid = 639111

    token = encrypt_g_auth(
        method="GET",
        path="/api/advertising/publishers/instagram/jobs",
        body=None,
        signing_key=sk,
        device_id=dev,
        user_id=uid,
    )
    decoded = decrypt_g_auth(token, sk)

    assert decoded["n"] == "GET"
    assert decoded["d"] == dev
    assert decoded["u"] == uid
    assert decoded["k"] == "/api/advertising/publishers/instagram/jobs"
    assert decoded["q"] == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    assert len(decoded["r"]) == 16
    assert isinstance(decoded["t"], int)
    assert isinstance(decoded["x"], str) and len(decoded["x"]) > 0

    # Mỗi lần encrypt phải ra token khác (nonce + IV + timestamp)
    token2 = encrypt_g_auth(
        method="GET",
        path="/api/advertising/publishers/instagram/jobs",
        body=None,
        signing_key=sk,
        device_id=dev,
        user_id=uid,
    )
    assert token != token2, "2 lan encrypt phai ra token khac nhau (nonce/IV/timestamp)"
    decoded2 = decrypt_g_auth(token2, sk)
    assert decoded2["n"] == decoded["n"]
    assert decoded2["k"] == decoded["k"]

    print("[gauth._selftest] OK — token1:", token[:40] + "...")
    print("[gauth._selftest] OK — token2:", token2[:40] + "...")
    print("[gauth._selftest] payload:", decoded)


if __name__ == "__main__":
    _selftest()
