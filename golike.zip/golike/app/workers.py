"""
app/workers.py - WorkerThread: mỗi worker = 1 GolikeAuth, chạy tuần tự qua tất cả providers.

Đây là phần "thread" trong multi-account/multi-thread.
Mỗi request tự ký g-auth qua bot.get_*() → app.utils.api → app.gauth.
"""
import time
import threading
import queue
from datetime import datetime
from typing import Dict

from app.auth import GolikeAuth
from app.utils.api import get_me
from app.ui import Colors, safe_print, countdown
from app.utils.config import CONFIG
from app.providers import ALL_PROVIDERS


class WorkerThread(threading.Thread):
    """1 worker = 1 GolikeAuth, chạy vòng qua tất cả platforms."""

    def __init__(self, auth: GolikeAuth, worker_id: int, stats_queue: queue.Queue):
        super().__init__(daemon=True)
        self.auth = auth
        self.worker_id = worker_id
        self.stats_queue = stats_queue
        self.running = True

        self.stats: Dict = {
            'auth': auth.username or auth.token[:15] + '...',
            'username': auth.username or 'Unknown',
            'user_id': auth.user_id,
            'coin': 0,
            'status': 'initializing',
            'total_earned': 0,
            'jobs_done': 0,
            'last_update': datetime.now(),
        }

        self.platforms = ALL_PROVIDERS  # [(name, bot_class), ...]
        self.max_errors = CONFIG['dung_sau_loi']
        self.delay_sec = CONFIG['delay_giay']
        self.jobs_target = CONFIG['so_luong_job']

    # ---------- user info ----------
    def update_user_info(self) -> bool:
        """Gọi /users/me để cập nhật username/coin/status."""
        try:
            resp = get_me(self.auth)
            if resp and resp.get('status') == 200:
                data = resp['data']
                self.stats['username'] = data.get('username', data.get('name', self.auth.username))
                self.stats['coin'] = data.get('coin', 0)
                self.stats['status'] = 'active'
                return True
            self.stats['status'] = 'invalid_token'
            return False
        except Exception as e:
            self.stats['status'] = f'error: {str(e)[:20]}'
            return False

    # ---------- main loop 1 platform ----------
    def run_platform(self, platform_name: str, bot_class):
        """Chạy hết jobs_target jobs cho 1 platform, tự xoay vòng accounts và xử lý lỗi."""
        bot = bot_class(self.auth)
        accounts_resp = bot.get_accounts()
        if not accounts_resp or accounts_resp.get('status') != 200:
            safe_print(f"{Colors.RED}[Worker {self.worker_id}] Không thể lấy danh sách tài khoản {platform_name}!{Colors.RESET}")
            return

        accounts = accounts_resp.get('data', []) or []
        if not accounts:
            safe_print(f"{Colors.RED}[Worker {self.worker_id}] Không có tài khoản {platform_name} nào!{Colors.RESET}")
            return

        safe_print(f"\n{Colors.GREEN}[Worker {self.worker_id}] {platform_name}: Tìm thấy {len(accounts)} tài khoản{Colors.RESET}")
        for i, acc in enumerate(accounts):
            safe_print(f"  [{i}] {bot.account_display_name(acc, i)} (ID: {bot.account_id(acc)})")

        safe_print(f"\n{Colors.BOLD_GREEN}[Worker {self.worker_id}] {platform_name}: Bắt đầu chạy {self.jobs_target} jobs...{Colors.RESET}")
        safe_print(f"{Colors.CYAN}{'='*60}{Colors.RESET}")

        account_errors: Dict[str, int] = {bot.account_id(acc): 0 for acc in accounts}
        consecutive_errors = 0
        account_index = 0
        jobs_done = 0
        total_earned = 0

        for i in range(self.jobs_target):
            if not self.running:
                break
            if consecutive_errors >= self.max_errors:
                safe_print(f"\n{Colors.BOLD_RED}[Worker {self.worker_id}] Đạt giới hạn {self.max_errors} lỗi liên tiếp. Dừng {platform_name}.{Colors.RESET}")
                break

            attempts = 0
            while attempts < len(accounts):
                current_account = accounts[account_index]
                acc_id = bot.account_id(current_account)
                if account_errors.get(acc_id, 0) < 3:
                    break
                account_index = (account_index + 1) % len(accounts)
                attempts += 1
            else:
                safe_print(f"{Colors.RED}[Worker {self.worker_id}] Tất cả tài khoản đều lỗi! Dừng {platform_name}.{Colors.RESET}")
                break

            current_account = accounts[account_index]
            acc_id = bot.account_id(current_account)
            acc_name = bot.account_display_name(current_account, account_index)

            job_resp = bot.get_job(acc_id)
            if not job_resp or job_resp.get('status') != 200:
                msg = (job_resp or {}).get('message', 'Unknown error')
                safe_print(f"{Colors.RED}[Worker {self.worker_id}] [{i+1}/{self.jobs_target}] [{acc_name}] No job: {msg}. Switching...{Colors.RESET}")
                account_errors[acc_id] = account_errors.get(acc_id, 0) + 1
                consecutive_errors += 1
                account_index = (account_index + 1) % len(accounts)
                countdown(2, "Switching")
                continue

            job_data = job_resp['data']
            job_type = job_data.get('type', 'unknown')
            link = job_data.get('link', '')
            object_id = job_data.get('object_id', '')
            ads_id = job_data.get('id', '')

            safe_print(f"{Colors.CYAN}[Worker {self.worker_id}] [{i+1}/{self.jobs_target}] [{acc_name}] {job_type.upper()} | {link[:35]}...{Colors.RESET}")
            countdown(10, "Processing")

            success = False
            for attempt in range(3):
                complete_resp = bot.complete_job(ads_id, acc_id)
                if complete_resp and (complete_resp.get('success') or complete_resp.get('status') == 200):
                    success = True
                    jobs_done += 1
                    earned = complete_resp.get('data', {}).get('prices', 0)
                    total_earned += earned
                    self.stats['total_earned'] += earned
                    self.stats['jobs_done'] += 1
                    account_errors[acc_id] = 0
                    consecutive_errors = 0

                    now_str = datetime.now().strftime("%H:%M:%S")
                    safe_print(
                        f"{Colors.BOLD_RED}| {Colors.BOLD_CYAN}{self.stats['jobs_done']}{Colors.BOLD_RED} | "
                        f"{Colors.BOLD_YELLOW}{now_str}{Colors.BOLD_RED} | "
                        f"{Colors.BOLD_GREEN}SUCCESS{Colors.BOLD_RED} | "
                        f"{Colors.BOLD_BLUE}{platform_name.upper()}:{job_type}{Colors.BOLD_RED} | "
                        f"{Colors.BOLD_GREEN}+{earned}{Colors.BOLD_RED} | "
                        f"{Colors.BOLD_YELLOW}{self.stats['total_earned']} VND{Colors.RESET}"
                    )
                    break
                else:
                    if attempt < 2:
                        safe_print(f"{Colors.YELLOW}[Worker {self.worker_id}] Thử lại lần {attempt+2}/3...{Colors.RESET}")
                        countdown(3, "Retry")

            if not success:
                safe_print(f"{Colors.RED}[Worker {self.worker_id}] Failed sau 3 lần! Switching...{Colors.RESET}")
                account_errors[acc_id] = account_errors.get(acc_id, 0) + 1
                consecutive_errors += 1
                bot.skip_job(ads_id, acc_id, object_id)

            account_index = (account_index + 1) % len(accounts)
            if self.delay_sec > 10:
                countdown(self.delay_sec - 10, "Delay")
            elif self.delay_sec > 0:
                time.sleep(self.delay_sec)

        safe_print(f"{Colors.BOLD_GREEN}{'='*60}{Colors.RESET}")
        safe_print(f"{Colors.BOLD_GREEN}[Worker {self.worker_id}] {platform_name} hoàn thành: {jobs_done} jobs | Kiếm được: {total_earned} VND{Colors.RESET}")

    # ---------- thread entry ----------
    def run(self):
        if not self.update_user_info():
            self.stats['status'] = 'invalid_token'
            self.push_stats()
            return

        self.push_stats()
        safe_print(f"{Colors.GREEN}[Worker {self.worker_id}] Started for {self.stats['username']} (Coin: {self.stats['coin']}){Colors.RESET}")

        while self.running:
            for platform_name, bot_class in self.platforms:
                if not self.running:
                    break
                safe_print(f"\n{Colors.BOLD_MAGENTA}[Worker {self.worker_id}] >>> Chuyển sang {platform_name} <<<{Colors.RESET}")
                self.run_platform(platform_name, bot_class)
                self.update_user_info()
                self.push_stats()
                if self.running:
                    safe_print(f"{Colors.YELLOW}[Worker {self.worker_id}] Nghỉ 5s trước khi sang nền tảng tiếp theo...{Colors.RESET}")
                    time.sleep(5)

    def push_stats(self):
        self.stats['last_update'] = datetime.now()
        self.stats_queue.put((self.worker_id, self.stats.copy()))

    def stop(self):
        self.running = False
