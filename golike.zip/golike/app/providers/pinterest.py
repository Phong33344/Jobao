"""
app/providers/pinterest.py - Pinterest provider
"""
from app.providers.base import BaseProviderBot


class PinterestBot(BaseProviderBot):
    platform = "pinterest"

    def __init__(self, auth):
        super().__init__(auth)
