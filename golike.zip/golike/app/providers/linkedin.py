"""
app/providers/linkedin.py - LinkedIn provider
"""
from app.providers.base import BaseProviderBot


class LinkedInBot(BaseProviderBot):
    platform = "linkedin"

    def __init__(self, auth):
        super().__init__(auth)
