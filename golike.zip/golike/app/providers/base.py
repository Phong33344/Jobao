"""
app/providers/base.py - BaseProviderBot

Định nghĩa các commands (commands) chung cho mọi platform:
  - get_accounts()
  - get_job(account_id)
  - complete_job(ads_id, account_id)
  - skip_job(ads_id, account_id, object_id)

Mỗi provider con chỉ cần set `platform = "..."`.
Mỗi command tự ký g-auth qua app.utils.api (GolikeAuth).
"""
from typing import Optional, Dict, Any

from app.auth import GolikeAuth
from app.utils.api import get, post
from app.ui import Colors, safe_print


class BaseProviderBot:
    """Base class cho mọi platform (Twitter, LinkedIn, Threads, Pinterest, Snapchat, ...)."""

    platform: str = ""

    def __init__(self, auth: GolikeAuth, platform: str = ""):
        if platform:
            self.platform = platform
        if not self.platform:
            raise ValueError("BaseProviderBot: subclass phải set `platform` hoặc truyền platform=")
        self.auth = auth  # GolikeAuth (5 trường)

    # ---------- commands ----------
    def get_accounts(self) -> Optional[Dict[str, Any]]:
        """GET /{platform}-account — list accounts user đang kết nối."""
        return get(self.auth, f"/{self.platform}-account")

    def get_job(self, account_id: str) -> Optional[Dict[str, Any]]:
        """GET /advertising/publishers/{platform}/jobs — lấy 1 job."""
        return get(
            self.auth,
            f"/advertising/publishers/{self.platform}/jobs",
            params={"account_id": account_id, "data": "null"},
        )

    def complete_job(self, ads_id: str, account_id: str) -> Optional[Dict[str, Any]]:
        """POST /advertising/publishers/{platform}/complete-jobs — báo đã làm xong."""
        payload = {
            "ads_id": ads_id,
            "account_id": account_id,
            "async": True,
            "data": None,
        }
        return post(
            self.auth,
            f"/advertising/publishers/{self.platform}/complete-jobs",
            json_body=payload,
        )

    def skip_job(self, ads_id: str, account_id: str, object_id: str):
        """POST /advertising/publishers/{platform}/skip-jobs — bỏ qua job."""
        payload = {
            "ads_id": ads_id,
            "account_id": account_id,
            "object_id": object_id,
        }
        try:
            post(
                self.auth,
                f"/advertising/publishers/{self.platform}/skip-jobs",
                json_body=payload,
            )
        except Exception:
            pass

    # ---------- helpers ----------
    def account_display_name(self, acc: Dict[str, Any], idx: int) -> str:
        return acc.get('name') or acc.get('username') or acc.get('screen_name') or f"Account {idx}"

    def account_id(self, acc: Dict[str, Any]) -> str:
        return str(acc.get('id', 'N/A'))
