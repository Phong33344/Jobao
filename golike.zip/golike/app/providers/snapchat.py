"""
app/providers/snapchat.py - Snapchat provider
"""
from app.providers.base import BaseProviderBot


class SnapchatBot(BaseProviderBot):
    platform = "snapchat"

    def __init__(self, auth):
        super().__init__(auth)
