"""
app/providers/threads.py - Threads (Meta) provider
"""
from app.providers.base import BaseProviderBot


class ThreadsBot(BaseProviderBot):
    platform = "threads"

    def __init__(self, auth):
        super().__init__(auth)
