"""
app/providers/twitter.py - Twitter/X provider
"""
from app.providers.base import BaseProviderBot


class TwitterBot(BaseProviderBot):
    platform = "twitter"

    def __init__(self, auth):
        super().__init__(auth)
