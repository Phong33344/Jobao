"""
app/providers/__init__.py - Registry chứa tất cả provider bots.
    from app.providers import TwitterBot, LinkedInBot, ...
    from app.providers import ALL_PROVIDERS, get_bot
"""
from app.providers.base import BaseProviderBot
from app.providers.twitter import TwitterBot
from app.providers.linkedin import LinkedInBot
from app.providers.threads import ThreadsBot
from app.providers.pinterest import PinterestBot
from app.providers.snapchat import SnapchatBot


ALL_PROVIDERS = [
    ("Twitter", TwitterBot),
    ("LinkedIn", LinkedInBot),
    ("Threads", ThreadsBot),
    ("Pinterest", PinterestBot),
    ("Snapchat", SnapchatBot),
]


def get_bot(platform_name: str, auth) -> BaseProviderBot:
    """Factory: trả về instance bot theo tên (case-insensitive)."""
    for name, cls in ALL_PROVIDERS:
        if name.lower() == platform_name.lower():
            return cls(auth)
    raise ValueError(f"Unknown platform: {platform_name}")


__all__ = [
    "BaseProviderBot",
    "TwitterBot",
    "LinkedInBot",
    "ThreadsBot",
    "PinterestBot",
    "SnapchatBot",
    "ALL_PROVIDERS",
    "get_bot",
]
