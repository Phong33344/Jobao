"""
app/single.py - SingleAccountRunner

Chạy 1 GolikeAuth qua tất cả platforms (đơn luồng, không queue/webhook).
Mỗi request tự ký g-auth qua bot.get_*() → app.utils.api → app.gauth.
"""
import time
from datetime import datetime
from typing import Optional, Dict

from app.auth import GolikeAuth
from app.utils.api import get_me
from app.ui import Colors, safe_print, countdown
from app.utils.config import CONFIG
from app.providers import ALL_PROVIDERS, get_bot


class SingleAccountRunner:
    def __init__(self, auth: GolikeAuth):
        self.auth = auth
        self.running = True
        self.stats = {
            'username': auth.username,
            'user_id': auth.user_id,
            'coin': 0,
            'total_earned': 0,
            'jobs_done': 0,
        }
        self.max_errors = CONFIG['dung_sau_loi']
        self.delay_sec = CONFIG['delay_giay']
        self.jobs_target = CONFIG['so_luong_job']
        self.platforms = ALL_PROVIDERS

    # ---------- user info ----------
    def show_profile(self) -> bool:
        """In thông tin user hiện tại, trả về True nếu GolikeAuth hợp lệ."""
        try:
            resp = get_me(self.auth)
            if resp and resp.get('status') == 200:
                data = resp['data']
                self.stats['username'] = data.get('username', data.get('name', self.auth.username))
                self.stats['coin'] = data.get('coin', 0)
                safe_print(f"\n{Colors.BOLD_GREEN}{'='*60}{Colors.RESET}")
                safe_print(f"{Colors.BOLD_CYAN}  Username : {Colors.BOLD_WHITE}{self.stats['username']}{Colors.RESET}")
                safe_print(f"{Colors.BOLD_CYAN}  User ID  : {Colors.BOLD_WHITE}{self.auth.user_id}{Colors.RESET}")
                safe_print(f"{Colors.BOLD_CYAN}  Device   : {Colors.BOLD_WHITE}{self.auth.device_id}{Colors.RESET}")
                safe_print(f"{Colors.BOLD_CYAN}  Coin     : {Colors.BOLD_YELLOW}{self.stats['coin']}{Colors.RESET}")
                safe_print(f"{Colors.BOLD_GREEN}{'='*60}{Colors.RESET}\n")

                # /users/me KHÔNG bắt buộc g-auth; jobs thì CÓ.
                # Phải verify signing_key qua /security/echo trước khi chạy job.
                safe_print(f"{Colors.CYAN}  Dang kiem tra signing_key (g-auth)...{Colors.RESET}")
                v = self.auth.verify_signing_key()
                if not v.get("ok"):
                    safe_print(f"{Colors.RED}  signing_key SAI / het han (server decrypt_fail){Colors.RESET}")
                    safe_print(f"{Colors.YELLOW}  Loi: {v.get('errors')}{Colors.RESET}")
                    safe_print(
                        f"{Colors.YELLOW}  Lay lai tu browser (da login dung acc):\n"
                        f"    document.querySelector('#app').__vue__.$store.state.signing_key\n"
                        f"  Roi cap nhat config.json (signing_key).{Colors.RESET}\n"
                    )
                    return False
                safe_print(f"{Colors.GREEN}  signing_key OK (server decrypt duoc g-auth){Colors.RESET}\n")
                return True
            safe_print(f"{Colors.RED}Token không hợp lệ!{Colors.RESET}")
            return False
        except Exception as e:
            safe_print(f"{Colors.RED}Lỗi khi lấy profile: {e}{Colors.RESET}")
            return False

    def update_coin(self):
        try:
            resp = get_me(self.auth)
            if resp and resp.get('status') == 200:
                self.stats['coin'] = resp['data'].get('coin', 0)
        except Exception:
            pass

    # ---------- list accounts ----------
    def list_accounts(self, platform_name: Optional[str] = None):
        targets = (
            [(platform_name, get_bot(platform_name, self.auth))]
            if platform_name
            else [(name, get_bot(name, self.auth)) for name, _ in self.platforms]
        )
        for name, bot in targets:
            resp = bot.get_accounts()
            safe_print(f"\n{Colors.BOLD_CYAN}── {name} ──{Colors.RESET}")
            if not resp or resp.get('status') != 200:
                safe_print(f"{Colors.RED}  Không lấy được: {(resp or {}).get('message', 'no response')}{Colors.RESET}")
                continue
            accounts = resp.get('data', []) or []
            if not accounts:
                safe_print(f"{Colors.YELLOW}  (rỗng){Colors.RESET}")
                continue
            for i, acc in enumerate(accounts):
                acc_name = bot.account_display_name(acc, i)
                acc_id = bot.account_id(acc)
                safe_print(f"  [{i}] {acc_name}  {Colors.CYAN}(ID: {acc_id}){Colors.RESET}")

    # ---------- main loop 1 platform ----------
    def run_platform(self, platform_name: str) -> int:
        bot = get_bot(platform_name, self.auth)
        accounts_resp = bot.get_accounts()
        if not accounts_resp or accounts_resp.get('status') != 200:
            safe_print(f"{Colors.RED}Không thể lấy danh sách tài khoản {platform_name}!{Colors.RESET}")
            return 0

        accounts = accounts_resp.get('data', []) or []
        if not accounts:
            safe_print(f"{Colors.RED}Không có tài khoản {platform_name} nào!{Colors.RESET}")
            return 0

        safe_print(f"\n{Colors.GREEN}{platform_name}: Tìm thấy {len(accounts)} tài khoản{Colors.RESET}")
        for i, acc in enumerate(accounts):
            safe_print(f"  [{i}] {bot.account_display_name(acc, i)} (ID: {bot.account_id(acc)})")

        safe_print(f"\n{Colors.BOLD_GREEN}Bắt đầu chạy {self.jobs_target} jobs trên {platform_name}...{Colors.RESET}")
        safe_print(f"{Colors.CYAN}{'='*60}{Colors.RESET}")

        account_errors: Dict[str, int] = {bot.account_id(acc): 0 for acc in accounts}
        consecutive_errors = 0
        account_index = 0
        jobs_done = 0
        total_earned = 0

        for i in range(self.jobs_target):
            if not self.running:
                break
            if consecutive_errors >= self.max_errors:
                safe_print(f"\n{Colors.BOLD_RED}Đạt giới hạn {self.max_errors} lỗi liên tiếp. Dừng {platform_name}.{Colors.RESET}")
                break

            attempts = 0
            while attempts < len(accounts):
                current_account = accounts[account_index]
                acc_id = bot.account_id(current_account)
                if account_errors.get(acc_id, 0) < 3:
                    break
                account_index = (account_index + 1) % len(accounts)
                attempts += 1
            else:
                safe_print(f"{Colors.RED}Tất cả tài khoản đều lỗi! Dừng {platform_name}.{Colors.RESET}")
                break

            current_account = accounts[account_index]
            acc_id = bot.account_id(current_account)
            acc_name = bot.account_display_name(current_account, account_index)

            job_resp = bot.get_job(acc_id)
            if not job_resp or job_resp.get('status') != 200:
                msg = (job_resp or {}).get('message', 'Unknown error')
                # 403 "cap nhat phien ban" thuong = g-auth fail (signing_key sai),
                # KHONG phai thieu job. /users/me van 200 du signing_key sai.
                if job_resp and job_resp.get("status") == 403 and (
                    "phien ban" in str(msg).lower()
                    or "phiên bản" in str(msg)
                    or "cập nhật" in str(msg)
                ):
                    safe_print(
                        f"{Colors.RED}[{i+1}/{self.jobs_target}] 403 g-auth fail "
                        f"(signing_key sai/het han), khong phai het job.{Colors.RESET}"
                    )
                    safe_print(
                        f"{Colors.YELLOW}  Lay signing_key moi tu browser store, "
                        f"cap nhat config.json roi chay lai.{Colors.RESET}"
                    )
                    break
                safe_print(f"{Colors.RED}[{i+1}/{self.jobs_target}] [{acc_name}] No job: {msg}. Switching...{Colors.RESET}")
                account_errors[acc_id] = account_errors.get(acc_id, 0) + 1
                consecutive_errors += 1
                account_index = (account_index + 1) % len(accounts)
                countdown(2, "Switching")
                continue

            job_data = job_resp['data']
            job_type = job_data.get('type', 'unknown')
            link = job_data.get('link', '')
            object_id = job_data.get('object_id', '')
            ads_id = job_data.get('id', '')

            safe_print(f"{Colors.CYAN}[{i+1}/{self.jobs_target}] [{acc_name}] {job_type.upper()} | {link[:35]}...{Colors.RESET}")
            countdown(10, "Processing")

            success = False
            for attempt in range(3):
                complete_resp = bot.complete_job(ads_id, acc_id)
                if complete_resp and (complete_resp.get('success') or complete_resp.get('status') == 200):
                    success = True
                    jobs_done += 1
                    earned = complete_resp.get('data', {}).get('prices', 0)
                    total_earned += earned
                    self.stats['total_earned'] += earned
                    self.stats['jobs_done'] += 1
                    account_errors[acc_id] = 0
                    consecutive_errors = 0

                    now_str = datetime.now().strftime("%H:%M:%S")
                    safe_print(
                        f"{Colors.BOLD_RED}| {Colors.BOLD_CYAN}{self.stats['jobs_done']}{Colors.BOLD_RED} | "
                        f"{Colors.BOLD_YELLOW}{now_str}{Colors.BOLD_RED} | "
                        f"{Colors.BOLD_GREEN}SUCCESS{Colors.BOLD_RED} | "
                        f"{Colors.BOLD_BLUE}{platform_name.upper()}:{job_type}{Colors.BOLD_RED} | "
                        f"{Colors.BOLD_GREEN}+{earned}{Colors.BOLD_RED} | "
                        f"{Colors.BOLD_YELLOW}{self.stats['total_earned']} VND{Colors.RESET}"
                    )
                    break
                else:
                    if attempt < 2:
                        safe_print(f"{Colors.YELLOW}Thử lại lần {attempt+2}/3...{Colors.RESET}")
                        countdown(3, "Retry")

            if not success:
                safe_print(f"{Colors.RED}Failed sau 3 lần! Switching...{Colors.RESET}")
                account_errors[acc_id] = account_errors.get(acc_id, 0) + 1
                consecutive_errors += 1
                bot.skip_job(ads_id, acc_id, object_id)

            account_index = (account_index + 1) % len(accounts)
            if self.delay_sec > 10:
                countdown(self.delay_sec - 10, "Delay")
            elif self.delay_sec > 0:
                time.sleep(self.delay_sec)

        safe_print(f"{Colors.BOLD_GREEN}{'='*60}{Colors.RESET}")
        safe_print(f"{Colors.BOLD_GREEN}{platform_name} hoàn thành: {jobs_done} jobs | Kiếm được: {total_earned} VND{Colors.RESET}")
        return jobs_done

    # ---------- top-level ----------
    def run(self, only_platform: Optional[str] = None):
        if not self.show_profile():
            return

        safe_print(f"{Colors.BOLD_GREEN}Bắt đầu chạy tự động...{Colors.RESET}")
        try:
            while self.running:
                for platform_name, _ in self.platforms:
                    if not self.running:
                        break
                    if only_platform and platform_name.lower() != only_platform.lower():
                        continue
                    safe_print(f"\n{Colors.BOLD_MAGENTA}>>> Chuyển sang {platform_name} <<<{Colors.RESET}")
                    self.run_platform(platform_name)
                    self.update_coin()
                    safe_print(f"{Colors.CYAN}  ↳ Coin hiện tại: {self.stats['coin']} | Tổng kiếm: {self.stats['total_earned']} VND{Colors.RESET}")
                    if self.running:
                        safe_print(f"{Colors.YELLOW}Nghỉ 5s trước khi sang nền tảng tiếp theo...{Colors.RESET}")
                        time.sleep(5)
        except KeyboardInterrupt:
            safe_print(f"\n{Colors.BOLD_YELLOW}Đã dừng bởi người dùng.{Colors.RESET}")
        finally:
            safe_print(f"{Colors.BOLD_GREEN}Tổng kết: {self.stats['jobs_done']} jobs | {self.stats['total_earned']} VND{Colors.RESET}")

    def stop(self):
        self.running = False
